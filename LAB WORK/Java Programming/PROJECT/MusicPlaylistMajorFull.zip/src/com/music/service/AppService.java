package com.music.service;

import com.music.dao.*;
import com.music.model.*;
import com.music.util.*;
import java.util.List;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class AppService {
    private final UserDAO userDAO = new UserDAO();
    private final PlaylistDAO playlistDAO = new PlaylistDAO();
    private final MediaItemDAO mediaDAO = new MediaItemDAO();

    public static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(input.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte by : b) sb.append(String.format("%02x", by));
            return sb.toString();
        } catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException(ex);
        }
    }

    public boolean register(String username, String password) {
        if (userDAO.findByUsername(username) != null) return false;
        String hash = sha256(password);
        User u = new User(username, hash);
        return userDAO.createUser(u);
    }

    public User login(String username, String password) {
        User u = userDAO.findByUsername(username);
        if (u == null) return null;
        String hash = sha256(password);
        return hash.equals(u.getPasswordHash()) ? u : null;
    }

    public int createPlaylist(String name, String description, int userId) {
        Playlist p = new Playlist(name, description, userId);
        return playlistDAO.createPlaylist(p);
    }

    public List<Playlist> listUserPlaylists(int userId) {
        return playlistDAO.getPlaylistsByUser(userId);
    }

    public Playlist getPlaylistIfOwned(int id, int userId) {
        return playlistDAO.findByIdAndUser(id, userId);
    }

    public boolean removePlaylist(int id, int userId) {
        return playlistDAO.deleteByIdAndUser(id, userId);
    }

    public int addSongToPlaylist(int playlistId, String title, String artist, String album, int duration) {
        Song s = new Song(title, artist, album, duration, playlistId);
        return mediaDAO.addMediaItem(s);
    }

    public List<MediaItem> getSongsInPlaylist(int playlistId) {
        return mediaDAO.getByPlaylist(playlistId);
    }

    public boolean removeSong(int songId) {
        return mediaDAO.deleteById(songId);
    }
}
